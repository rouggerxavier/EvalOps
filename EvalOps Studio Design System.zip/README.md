# EvalOps Studio — Design System

> Design system for **EvalOps Studio**, a mini-SaaS for **LLMOps / AgentOps** — observability, tracing, automatic evaluation and continuous improvement of LLM and agent applications.

This system codifies the visual language of EvalOps Studio: a premium, technical, dark-mode dashboard that should feel at home next to LangSmith, Langfuse, Sentry and Datadog. It is engineered for AI engineers and tech leads, not casual users — high information density, calm color, and nothing that smells like generic "AI SaaS".

---

## Sources

This system was built from materials provided by the user:

- **Reference screenshot**: `assets/reference-dashboard.png` — the canonical Project Overview mock the user wants the dashboard to look like.
- **Codebase**: GitHub repo `rouggerxavier/EvalOps` (private, `main` branch). Read on demand via the GitHub connector. Key files consulted:
  - `README.md` — product positioning.
  - `docs/00-project-overview.md` — product / problem framing.
  - `docs/01-product-requirements.md` — functional + non-functional requirements.
  - `docs/11-dashboard-and-analytics.md` — full screen map and UX principles.
  - `apps/web/app/globals.css` — original CSS variables (we kept the *intent*, modernized the values).
  - `apps/web/app/o/[org]/p/[project]/page.tsx` — Server Component that defines the overview's data shape.
  - `apps/web/lib/types.ts` — `Trace`, `OverviewResponse`, span shape.

The repo is in **Spec-Driven Development** phase — there is no shipped UI yet. This design system is the *target* visual the user is implementing toward.

---

## Index

| File / folder | What it is |
|---|---|
| `README.md` | This file: product context, fundamentals, iconography, manifest. |
| `colors_and_type.css` | All design tokens — colors, type, spacing, radii, shadows. Single source of truth. |
| `SKILL.md` | Agent SKILL definition (works in Claude Code too). |
| `assets/` | Brand assets: reference screenshot, logos, illustrations. |
| `preview/` | Small HTML cards that populate the Design System tab — colors, type, badges, buttons, KPIs, charts. |
| `ui_kits/dashboard/` | The flagship UI kit: a clickable, hi-fi recreation of the EvalOps Studio app (Project Overview, Traces, etc). |

---

## Product context (one-paragraph version)

EvalOps Studio is the *observability, governance and quality* layer for AI applications. Teams instrument their agents with the `evalops-python` SDK (a `@trace` decorator), capture rich traces (prompt, response, tools, tokens, cost, latency, fallback, errors), evaluate responses with declarative YAML rubrics (LLM-as-judge + heuristics), compare prompt/model versions in regression tests, and export datasets for fine-tuning. The flagship demo project is **DocOps Agent** running inside the **Rogue Labs** workspace.

The platform must communicate, at a glance, that:
- Traces are being ingested.
- Evaluations are running.
- Rubrics are active and versioned.
- Models / providers are being monitored (cost + latency).
- Critical flags and alerts exist and are actionable.
- API keys + Python SDK are first-class.

---

## Content fundamentals

**Tone.** Calm, technical, precise. No marketing fluff, no exclamation marks, no smiley-face copy. Read like a Datadog or Sentry surface, not a Notion landing page.

**Voice.** Third-person / system-narrator for data ("Trace ingested", "Eval failed"). Second-person ("you") only in onboarding and empty states ("Ship your first trace in 3 lines"). First-person plural ("we") is forbidden — this is a tool, not a brand persona.

**Casing.**
- **Sentence case** for everything: section titles ("Active rubrics"), buttons ("View all flags"), menu items ("API keys"). The reference uses Title Case for top-level headers ("Project Overview", "Active Rubrics", "Critical Flags") because they read like proper nouns of UI regions — keep that for nav + region headers and switch to sentence case for body actions.
- **UPPERCASE** with letter-spacing only for `.overline` micro-labels above KPIs (rare).
- **lowercase** with mono font for technical strings: `trace_9f8d2a7c`, `gpt-4o`, `prod`, `claude-3-opus`.

**Numbers.**
- Always tabular numerals (`font-variant-numeric: tabular-nums`).
- Currency: `$1,842.63` — leading symbol, comma thousands, two decimals for KPI cards.
- Latency: `2.48 s` for ≥1s, `742 ms` below.
- Percentages: `+18.6%` — explicit sign on deltas; `61% of $3,000 limit` for usage.
- Counts: `128,547` with comma thousands; `23 members` for small.

**Time language.** Relative for live data ("1m ago", "2m ago", "5m ago"), absolute UTC for everything older. Footer says "All times in UTC."

**Status verbs.** Use the literals from the data layer: `Passed`, `Failed`, `Needs Review`, `Active`, `Healthy`, `Critical`. Never invent synonyms — the badge text matches the API status enum.

**Empty states.** Educate, don't apologize. "Drop a trace to start. `pip install evalops` …" — show the snippet inline, not a "no data yet 😞".

**Emoji.** Forbidden. Anywhere. Status is communicated through colored dots, badges and icons — never `✅` / `⚠️` / `❌`.

**Language.** UI strings in **English** (the spec roadmap targets EN before public; pt-BR was an interim choice we are not preserving). Dates / units in en-US conventions.

**Examples to lift directly:**
- "AI observability, tracing and evaluation for production AI systems." (subtitle)
- "All systems operational" (footer pill)
- "Last seen: 1m ago" (SDK card)
- "Resets in 11 days" (billing micro-copy)

---

## Visual foundations

**Mode.** Dark-only. No light mode in scope. The product is for engineers; the surface is a console.

**Background system.** Layered navy → near-black, never pure black. Five surface tokens (`--surface-0` deepest → `--surface-4` highest elevation). Cards are `--surface-3` against a `--surface-1` canvas with a 1px `--border-subtle` line — no big drop shadows, no glassmorphism. The depth comes from *border + 1-step lighter background*, not blur.

**Color philosophy.**
- **Blue / cyan** for primary action, active nav, traces, line charts. The cyan is the "this is data flowing" cue.
- **Green** = passed / healthy / success only. Never decorative.
- **Amber** = needs-review / warning. Never "highlight".
- **Red** = failed / critical. Used sparingly so it stays loud.
- **Slate / gray** for structure, borders, secondary text. ~80% of pixels by area.
- Never orange, never magenta, never purple gradients. Forbidden combo: white + orange (we are not Datadog).

**Typography.**
- **Inter** for UI (400/500/600/700). Tracking tightens slightly at display sizes (`-0.02em`).
- **JetBrains Mono** for trace IDs, model names, code snippets.
- No serif faces. If we want emphasis, we use weight (600), not italic.

**Spacing.** 4px base scale (`--space-1` … `--space-12`). Cards use 16–20px internal padding, 12px gap between cards, 24px between major regions. Tables use 10–12px row padding — dense but breathable.

**Borders.** 1px, color-controlled. Three weights: `--border-subtle` for cards, `--border-default` for dividers between active regions, `--border-strong` for hover/focus. A border is always preferred to a shadow.

**Shadows.** Used minimally — only on popovers, tooltips, the avatar dropdown. Cards get an inset 1px highlight (`rgba(255,255,255,0.02)`) to give a millimetre of dimension, not a drop.

**Radii.** 6–10px range. Cards = 10px, buttons = 6–8px, inputs = 6px, badges/pills = 999px. No 4xl rounded-blob containers.

**Backgrounds & textures.** Flat. Optional ultra-subtle radial spotlight (`rgba(59,141,245,0.04)` at 20% top of the canvas) for visual rhythm. No grain, no gradients on cards, no abstract blobs, no AI-generated wallpaper. The chart areas may use a thin gradient *under* a line series (cyan @ 20% → 0%) — this is the only gradient permitted.

**Animation.**
- Easing: `cubic-bezier(0.2, 0.8, 0.2, 1)` standard; `cubic-bezier(0.16, 1, 0.3, 1)` for entry.
- Durations: 120ms (hover), 200ms (state change), 320ms (drawer / modal).
- No bounce, no spring, no parallax. UI feels instant.
- Charts animate on first paint only (line draws L→R, ~600ms), never on filter change.

**Hover.** Cards lift via border (`subtle → strong`) + 1-step lighter background. Buttons brighten by ~6% via lighter primary token. Never a translate / scale on hover.

**Press.** `active:` uses the next darker shade + a 1px inset; no scale-down. Focus ring is a 3px outer halo at 20% primary opacity — clearly visible without being chunky.

**Transparency / blur.** Only on the topbar when it overlaps the canvas (12px backdrop-blur), and on tooltip / popover backgrounds (`--surface-overlay` at 72% opacity over 8px blur). Cards are always solid.

**Imagery.** None in the dashboard surface. Brand marks are flat SVG / monochrome. If a future marketing surface needs photography, it should be cool-tone, low-saturation, with a `mix-blend-mode: lighten` cyan tint over a navy plate.

**Layout rules.**
- Desktop-first, 1440 minimum, 1920 sweet spot. Mobile is out of scope.
- Three-column flagship layout: left sidebar (240px), main canvas (fluid), right insight rail (320px).
- Topbar: 56px height, sticky, full-width, blurred when content scrolls under.
- Sidebar: 240px, fixed, with footer cards (API Keys, SDK Health) pinned to the bottom.

**Cards.** `--surface-3` background, `--border-subtle` 1px border, `--radius-lg` (10px), 16–20px padding, `--shadow-sm`. Hover bumps the border to `--border-default` and the bg to `--surface-4`.

**Status pills.** `--radius-pill`, `--space-2 --space-4` padding, 11–12px text, 1px border tinted to status color, soft tinted background (e.g. `--success-soft` / `--success-border`). Optional 6px colored dot prefix.

---

## Iconography

**Source.** EvalOps doesn't ship its own icon set yet. We use **Lucide** (https://lucide.dev) at **1.5px stroke**, 16–20px square. Lucide matches the technical / minimal feel of Sentry, Linear and Vercel — and it has every glyph the dashboard needs (`activity`, `database`, `flag`, `key`, `gauge`, `dollar-sign`, `bell`, `search`, `chevron-down`, …).

We load it via CDN in HTML cards and UI-kit pages:

```html
<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
<script>lucide.createIcons();</script>
```

> **Substitution flag.** Lucide is a stand-in: when the production app picks an icon library (likely `lucide-react` per shadcn convention) we should re-verify weight + size. Ask the user to confirm or supply a different set if they have brand SVGs.

**Logo.** EvalOps Studio doesn't have a finalized logo. The mock uses a stylized "EvalOps Studio" wordmark with a small concentric-target glyph in cyan. We've drawn a placeholder SVG mark in `assets/logo-evalops.svg` — flag for replacement if the user has a real one.

**Emoji.** Never used in product UI.

**Unicode.** Avoid as glyphs. Use proper SVG icons (`›` and `•` are the only allowed unicode atoms — chevron in breadcrumbs, dot in status / list separators).

**Status visualization.**
- Colored 6px circle prefix on text rows (alerts list, member status).
- Filled colored badge on tabular status cells (`Passed`, `Failed`, `Needs Review`).
- Stripe-style red/green/yellow segments inside score bars on the Recent Traces table.

---

## Caveats

- **Logo placeholder** — see Iconography. Replace when a real mark exists.
- **Lucide as icon set** — flagged substitution; confirm with user.
- **No brand fonts** — Inter + JetBrains Mono via Google Fonts. If EvalOps adopts something else, swap the `@import` and the `--font-sans` / `--font-mono` tokens.
- **Charts in the UI kit are hand-drawn SVG** (no Recharts dep) — they are visually faithful but should be reimplemented with Recharts in production per the spec.
