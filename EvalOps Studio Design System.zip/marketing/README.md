# Marketing & Auth UI Kit

Public-facing surfaces for EvalOps Studio: landing page, sign-in, sign-up, and the post-auth `/app` entrypoint. Designed to extend — never replace — the dashboard's dark navy / cyan identity.

## Files (HTML mocks → Next.js routes)

| HTML mock | Maps to in `apps/web/` |
|---|---|
| `index.html`        | `app/page.tsx` (replaces the dev placeholder) |
| `login.html`        | `app/login/page.tsx` |
| `register.html`     | `app/register/page.tsx` |
| `app-redirect.html` | `app/app/page.tsx` (entrypoint) |
| `marketing.css`     | merge into `app/globals.css` or keep as `app/(marketing)/marketing.css` and scope by route group |

The dashboard route stays untouched: `app/o/[org]/p/[project]/page.tsx` and friends are not modified.

## Visual rules followed

- Same token set as the dashboard (`colors_and_type.css`) — surfaces, primary blue, cyan accent, semantic colors.
- No light/pastel anywhere; navy `--surface-0` is the canvas, navy-grid + radial glow create depth without leaving the system.
- No "startup template" tropes: no big white-tile hero, no off-the-shelf "Get started for free" bar, no orange. The hero gradient runs white → blue-grey, never white → orange.
- Buttons match the dashboard's `--primary-500` gradient and `--surface-3` secondary.
- Code snippets use the same `--font-mono` (JetBrains Mono) and `--surface-2` plate as the dashboard.

## Auth shell

- **Split layout**: form on the left (single column, max 400px) — pane on the right with a live-feel product mock + quote.
- **Mock submission**: forms call `event.preventDefault()` and route to `/o/demo-org/p/demo-project`. Wire to Auth.js (NextAuth v5) per `docs/decisions/ADR-0005-auth-and-api-keys.md` when the backend lands.
- **OAuth slots**: GitHub + Magic link buttons match the spec's planned providers.

## Entrypoint (`/app`)

A small loading card that, in Next.js, becomes a Server Component:

```tsx
// app/app/page.tsx
import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";

export default async function AppEntry() {
  const session = await auth();
  if (!session) redirect("/login");
  const last = session.user.lastWorkspace ?? "demo-org/demo-project";
  redirect(`/o/${last}`);
}
```

The HTML mock here just shows the loading state.

## Responsive

- Desktop ≥ 880px: two-column auth, full nav, 4-col features.
- Below 880px: single column auth (side panel hidden), nav links collapse (no hamburger menu in the mock — add per shadcn `Sheet` when wiring).

## Caveats

- Forms are visual-only — no validation library, no zod schema. Wire `react-hook-form` + `zod` per the shadcn convention.
- Logo strip in the hero uses text glyphs (`OPENAI`, `ANTHROPIC`, …) since we don't have permission to use those marks. Replace with proper SVG logos before public launch.
- The hero dashboard preview is hand-drawn HTML/SVG so it stays in sync with the design tokens — when production data is available, swap for an actual screenshot of `ui_kits/dashboard/index.html`.
