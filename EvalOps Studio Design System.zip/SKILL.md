---
name: evalops-studio-design
description: Use this skill to generate well-branded interfaces and assets for EvalOps Studio (LLMOps / AgentOps observability), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

Files of note:
- `README.md` — full system: product context, content fundamentals, visual foundations, iconography.
- `colors_and_type.css` — single source of truth for all design tokens. Import it in any HTML you produce.
- `assets/` — logo, mark, reference dashboard screenshot.
- `preview/` — small specimen cards for every token / component class.
- `ui_kits/dashboard/` — clickable hi-fi recreation of the EvalOps Studio Project Overview screen with reusable JSX components (Sidebar, Topbar, KpiCards, Charts, RecentTraces, RightRail).

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. Always `@import "colors_and_type.css"` and use the tokens — never hard-code colors. If working on production code (Next.js + Tailwind + shadcn/ui per the spec), copy assets and lift token values from `colors_and_type.css` into the Tailwind theme.

If the user invokes this skill without any other guidance, ask them what they want to build or design (a new screen? a deck about EvalOps? a marketing surface?), ask a few questions about audience and scope, and act as an expert designer who outputs HTML artifacts _or_ production-shaped code, depending on the need.
