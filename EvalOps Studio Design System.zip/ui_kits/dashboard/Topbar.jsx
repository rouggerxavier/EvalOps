/* global React, Icon */
// Topbar.jsx — sticky topbar with project picker, env, range, search, notif, avatar

function Topbar() {
  return (
    <header className="topbar">
      <div className="project-picker">
        <span className="project-picker__label">Project</span>
        <span className="project-picker__name">DocOps Agent</span>
        <Icon name="chevron-down" />
      </div>
      <button className="star-btn" aria-label="Pin project">
        <Icon name="star" />
      </button>
      <div className="env-pill">Prod <Icon name="chevron-down" /></div>

      <div className="topbar__spacer" />

      <button className="tb-control">
        <Icon name="calendar" />
        <span>Last 7 days</span>
        <Icon name="chevron-down" />
      </button>
      <button className="tb-control">
        <span>prod</span>
        <Icon name="chevron-down" />
      </button>

      <div className="search">
        <Icon name="search" />
        <input placeholder="Search traces, evals, rubrics..." />
        <span className="kbd">/</span>
      </div>

      <button className="icon-btn" aria-label="Notifications">
        <Icon name="bell" />
        <span className="dot" />
      </button>

      <div className="avatar">RX</div>
    </header>
  );
}

window.Topbar = Topbar;
