/* global React */
// Sidebar.jsx — left navigation rail with workspace + nav + footer cards

const NAV = [
  { id: 'overview',   label: 'Overview',    icon: 'layout-dashboard', active: true },
  { id: 'traces',     label: 'Traces',      icon: 'activity' },
  { id: 'evals',      label: 'Evaluations', icon: 'gauge' },
  { id: 'rubrics',    label: 'Rubrics',     icon: 'list-checks' },
  { id: 'regression', label: 'Regression',  icon: 'git-compare' },
  { id: 'exports',    label: 'Exports',     icon: 'download' },
  { id: 'keys',       label: 'API Keys',    icon: 'key-round' },
  { id: 'settings',   label: 'Settings',    icon: 'settings' },
];

function Icon({ name, className }) {
  // Lucide is loaded globally; we render an <i data-lucide> placeholder and rely on lucide.createIcons()
  return React.createElement('i', { 'data-lucide': name, className });
}

function Sidebar() {
  const [active, setActive] = React.useState('overview');
  return (
    <aside className="sidebar">
      <div className="sidebar__brand">
        <img className="mark" src="../../assets/mark-evalops.svg" alt="" />
        <div className="name">EvalOps<span className="sub">Studio</span></div>
      </div>

      <div className="workspace">
        <div className="workspace__avatar">RL</div>
        <div className="workspace__meta">
          <span className="workspace__label">Workspace</span>
          <span className="workspace__name">Rogue Labs</span>
        </div>
        <Icon name="chevrons-up-down" className="workspace__chevron" />
      </div>

      <nav className="nav">
        {NAV.map(n => (
          <div key={n.id}
               className={`nav__item ${active === n.id ? 'active' : ''}`}
               onClick={() => setActive(n.id)}>
            <Icon name={n.icon} />
            <span>{n.label}</span>
          </div>
        ))}
      </nav>

      <div className="sidebar__footer">
        <div className="side-card">
          <div className="side-card__row">
            <div className="side-card__icon"><Icon name="key-round" /></div>
            <div style={{ flex: 1 }}>
              <div className="side-card__title">API Keys</div>
              <div className="side-card__meta">3 active</div>
            </div>
          </div>
        </div>

        <div className="side-card">
          <div className="side-card__row">
            <div className="side-card__icon" style={{ background: 'rgba(46,194,126,0.14)', color: 'var(--success)' }}>
              <Icon name="terminal" />
            </div>
            <div style={{ flex: 1 }}>
              <div className="side-card__title">SDK Python</div>
              <div className="side-card__meta">Ingestion Source</div>
            </div>
          </div>
          <div className="side-card__healthy">Healthy</div>
          <div className="side-card__lastseen">Last seen: 1m ago</div>
        </div>
      </div>
    </aside>
  );
}

window.Sidebar = Sidebar;
window.Icon = Icon;
