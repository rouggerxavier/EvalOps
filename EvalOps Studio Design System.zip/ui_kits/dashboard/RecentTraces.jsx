/* global React, Icon */
// RecentTraces.jsx — table of recent traces with status, model, score, latency, cost, env, time

const ROWS = [
  { id: 'trace_9f8d2a7c', status: 'passed',  model: 'gpt-4o',         score: 0.92, latency: '1.74 s',  cost: '$0.0214', env: 'prod', time: '2m ago' },
  { id: 'trace_1a3b9e21', status: 'passed',  model: 'claude-3-opus',  score: 0.88, latency: '2.11 s',  cost: '$0.0187', env: 'prod', time: '3m ago' },
  { id: 'trace_4d7e6b11', status: 'review',  model: 'gpt-4o',         score: 0.63, latency: '2.65 s',  cost: '$0.0231', env: 'prod', time: '5m ago' },
  { id: 'trace_8c2a7f90', status: 'failed',  model: 'gpt-4o',         score: 0.31, latency: '3.42 s',  cost: '$0.0248', env: 'prod', time: '7m ago' },
  { id: 'trace_c5d9e2ff', status: 'passed',  model: 'gpt-4-turbo',    score: 0.90, latency: '1.58 s',  cost: '$0.0156', env: 'prod', time: '9m ago' },
];

function StatusBadge({ status }) {
  if (status === 'passed') return <span className="badge badge--passed">Passed</span>;
  if (status === 'failed') return <span className="badge badge--failed">Failed</span>;
  if (status === 'review') return <span className="badge badge--review">Needs Review</span>;
  return null;
}

function ScoreCell({ value }) {
  const cls = value >= 0.7 ? '' : value >= 0.5 ? 'warn' : 'bad';
  return (
    <span className="score-cell">
      <span className="v">{value.toFixed(2)}</span>
      <span className={`score-bar ${cls}`}><i style={{ width: `${value * 100}%` }} /></span>
    </span>
  );
}

function RecentTraces() {
  return (
    <div className="card table-card">
      <div className="table-head">
        <div className="title">Recent Traces</div>
        <a href="#">View all traces ›</a>
      </div>
      <table className="t-table">
        <thead>
          <tr>
            <th>Trace ID</th>
            <th>Status</th>
            <th>Model</th>
            <th>Score</th>
            <th>Latency (P95)</th>
            <th>Cost</th>
            <th>Environment</th>
            <th>Time <span className="sort-arrow">▾</span></th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {ROWS.map(r => (
            <tr key={r.id} className="row">
              <td className="trace-id">{r.id}</td>
              <td><StatusBadge status={r.status} /></td>
              <td className="model">{r.model}</td>
              <td><ScoreCell value={r.score} /></td>
              <td>{r.latency}</td>
              <td>{r.cost}</td>
              <td><span className="badge badge--prod">{r.env}</span></td>
              <td>{r.time}</td>
              <td className="arrow">›</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

window.RecentTraces = RecentTraces;
