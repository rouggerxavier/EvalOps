/* global React, Sidebar, Topbar, KpiCards, Charts, RecentTraces, RightRail */

function App() {
  React.useEffect(() => {
    if (window.lucide && window.lucide.createIcons) {
      window.lucide.createIcons();
    }
  });
  return (
    <div className="app">
      <Sidebar />
      <div>
        <Topbar />
        <main className="main">
          <div className="page-header">
            <div>
              <h1>Project Overview</h1>
              <p className="sub">AI observability, tracing and evaluation for production AI systems.</p>
            </div>
            <div className="workspace-meta">
              <span>Workspace: <strong>Rogue Labs</strong></span>
              <span className="sep" />
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                <i data-lucide="users" style={{ width: 14, height: 14 }}></i> 23 members
              </span>
            </div>
          </div>

          <div className="layout">
            <div>
              <KpiCards />
              <Charts />
              <RecentTraces />
            </div>
            <RightRail />
          </div>

          <footer className="app-footer">
            <div>© 2026 EvalOps Studio, Inc.</div>
            <div className="links">
              <a href="#">Docs</a>
              <a href="#">Status</a>
              <a href="#">Privacy</a>
              <a href="#">Terms</a>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
              <span style={{ color: 'var(--fg-3)', fontSize: 12 }}>All times in UTC</span>
              <span className="ops">All systems operational</span>
            </div>
          </footer>
        </main>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
