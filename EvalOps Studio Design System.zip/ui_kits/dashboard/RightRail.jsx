/* global React, Icon */
// RightRail.jsx — Active Rubrics, Critical Flags, Model Usage, Alerts, Billing/Usage

function ActiveRubrics() {
  return (
    <div className="card">
      <div className="rail__head">
        <span className="title">Active Rubrics</span>
        <a href="#">View all</a>
      </div>
      {[
        { name: 'DocOps Quality', v: 'v3.2', primary: true },
        { name: 'Groundedness',   v: 'v2.1' },
        { name: 'Security & PII', v: 'v1.4' },
        { name: 'Tool Accuracy',  v: 'v1.0' },
      ].map(r => (
        <div key={r.name} className="rubric-row">
          <div className="name">{r.name} <span className="v">{r.v}</span></div>
          {r.primary
            ? <span className="badge badge--primary">Primary</span>
            : <span className="badge badge--passed">Active</span>}
        </div>
      ))}
    </div>
  );
}

function CriticalFlags() {
  const flags = [
    { msg: 'Failure rate spiked in RAG tool', when: '12m ago' },
    { msg: 'PII detected in model output',    when: '45m ago' },
    { msg: 'Eval score dropped for GPT-4o',   when: '1h ago' },
  ];
  return (
    <div className="card">
      <div className="rail__head">
        <span className="title">Critical Flags <span className="pill">3</span></span>
      </div>
      {flags.map(f => (
        <div key={f.msg} className="flag-row">
          <span className="dot" />
          <div className="body"><div className="msg">{f.msg}</div></div>
          <span className="when">{f.when}</span>
        </div>
      ))}
      <a href="#" style={{ color: 'var(--primary-300)', fontSize: 12, marginTop: 8, display: 'inline-block' }}>View all flags</a>
    </div>
  );
}

function ModelUsage() {
  // donut: 62.1 gpt-4o, 21.3 claude, 12.7 gpt-4-turbo, 3.9 other
  const segs = [
    { v: 62.1, c: '#3b8df5', label: 'gpt-4o' },
    { v: 21.3, c: '#22d3ee', label: 'claude-3-opus' },
    { v: 12.7, c: '#a78bfa', label: 'gpt-4-turbo' },
    { v:  3.9, c: '#5a6791', label: 'other' },
  ];
  const r = 38, cx = 48, cy = 48, C = 2 * Math.PI * r;
  let acc = 0;
  return (
    <div className="card">
      <div className="rail__head">
        <span className="title">Model Usage <span style={{ fontSize: 11, color: 'var(--fg-3)', fontWeight: 400 }}>(by traces)</span></span>
      </div>
      <div className="donut-row">
        <svg className="donut" viewBox="0 0 96 96">
          <circle cx={cx} cy={cy} r={r} fill="none" stroke="var(--surface-2)" strokeWidth="12" />
          {segs.map((s, i) => {
            const len = (s.v / 100) * C;
            const dasharray = `${len} ${C - len}`;
            const offset = -((acc / 100) * C);
            acc += s.v;
            return (
              <circle key={i} cx={cx} cy={cy} r={r} fill="none"
                      stroke={s.c} strokeWidth="12"
                      strokeDasharray={dasharray} strokeDashoffset={offset}
                      transform={`rotate(-90 ${cx} ${cy})`} />
            );
          })}
        </svg>
        <ul className="usage-list" style={{ listStyle: 'none', padding: 0, margin: 0 }}>
          {segs.map(s => (
            <li key={s.label} className="row">
              <span className="lbl"><span className="swatch" style={{ background: s.c }} /> {s.label}</span>
              <span className="pct">{s.v.toFixed(1)}%</span>
            </li>
          ))}
        </ul>
      </div>
      <a href="#" className="full-report">View full report ›</a>
    </div>
  );
}

function Alerts() {
  const alerts = [
    { kind: 'warn',   msg: 'High latency p95 > 2.5s', env: 'Prod', when: '5m ago' },
    { kind: 'danger', msg: 'Eval score < 0.7',         env: 'Prod', when: '15m ago' },
    { kind: 'warn',   msg: 'Error rate > 2%',          env: 'Prod', when: '1h ago' },
  ];
  return (
    <div className="card">
      <div className="rail__head">
        <span className="title">Alerts</span>
        <a href="#">View all</a>
      </div>
      {alerts.map((a, i) => (
        <div key={i} className={`alert-row ${a.kind}`}>
          <div className="left">
            <span className="dot" />
            <div className="body">
              <span className="msg">{a.msg}</span>
              <span className="meta"><span className="badge badge--prod">{a.env}</span></span>
            </div>
          </div>
          <span className="when">{a.when}</span>
        </div>
      ))}
    </div>
  );
}

function Billing() {
  return (
    <div className="card">
      <div className="rail__head">
        <span className="title">Billing / Usage</span>
        <a href="#">View billing</a>
      </div>
      <div style={{ fontSize: 11.5, color: 'var(--fg-3)' }}>Current period (May 13 — May 19)</div>
      <div className="billing-amount" style={{ marginTop: 6 }}>$1,842.63</div>
      <div className="billing-meta">
        <span className="text-success" style={{ fontWeight: 600 }}>↑ 14.2%</span> vs previous 7 days
      </div>
      <div className="usage-bar"><i /></div>
      <div className="usage-foot">
        <span>Usage: 61% of $3,000 limit</span>
        <span>Resets in 11 days</span>
      </div>
    </div>
  );
}

function RightRail() {
  return (
    <aside className="rail">
      <ActiveRubrics />
      <CriticalFlags />
      <ModelUsage />
      <Alerts />
      <Billing />
    </aside>
  );
}

window.RightRail = RightRail;
