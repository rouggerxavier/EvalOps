# Dashboard UI Kit

The flagship UI kit — a hi-fi recreation of the EvalOps Studio Project Overview screen.

## Files

- `index.html` — entry; loads React + Lucide + the JSX modules below.
- `dashboard.css` — layout-specific styles (sidebar, topbar, cards, charts, table). Tokens come from `../../colors_and_type.css`.
- `Sidebar.jsx` — left navigation rail with workspace selector, nav, API Keys + SDK Health footer cards.
- `Topbar.jsx` — sticky topbar (project picker, env, range, search, notifications, avatar).
- `KPICards.jsx` — `Total Traces`, `Avg Eval Score`, `P95 Latency`, `Estimated Cost`. Includes a reusable `Sparkline` component.
- `Charts.jsx` — `TracesOverTime` (line+area) and `EvalQuality` (stacked bars: Passed / Needs Review / Failed).
- `RecentTraces.jsx` — table with status badges (`Passed` / `Needs Review` / `Failed`), score bars, monospace trace IDs.
- `RightRail.jsx` — `Active Rubrics`, `Critical Flags`, `Model Usage` (donut), `Alerts`, `Billing / Usage`.
- `app.jsx` — composition of the page.

## Notes

- Charts are hand-drawn SVG. In production the spec calls for Recharts; these are visually faithful placeholders.
- Icons are Lucide via CDN, loaded with `lucide.createIcons()` after each render.
- Designed for desktop (≥1440 px). Not responsive — this is engineering-console territory.
