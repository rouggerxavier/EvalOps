/* global React, Icon */
// KPICards.jsx — Total Traces, Avg Eval Score, P95 Latency, Estimated Cost

function Sparkline({ data, color = 'var(--primary-400)', fill = 'rgba(59,141,245,0.18)' }) {
  const w = 240, h = 56, pad = 2;
  const min = Math.min(...data), max = Math.max(...data);
  const range = max - min || 1;
  const step = (w - pad*2) / (data.length - 1);
  const points = data.map((v,i) => [pad + i*step, h - pad - ((v - min) / range) * (h - pad*2)]);
  const path = 'M' + points.map(p => p.join(',')).join(' L');
  const area = path + ` L${pad + (data.length-1)*step},${h} L${pad},${h} Z`;
  return (
    <svg className="kpi__sparkline" viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" width="100%" height="56">
      <defs>
        <linearGradient id={`g-${color.replace(/[^a-z0-9]/gi,'')}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%"  stopColor={color} stopOpacity="0.32" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#g-${color.replace(/[^a-z0-9]/gi,'')})`} />
      <path d={path} fill="none" stroke={color} strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

function KpiCard({ label, icon, iconClass, value, unit, delta, deltaDir = 'up', deltaCtx, sparkData, sparkColor }) {
  const arrow = deltaDir === 'up' ? 'arrow-up' : 'arrow-down';
  return (
    <div className="card card--inset">
      <div className="kpi">
        <div className="kpi__head">
          <span>{label}</span>
          <span className={`kpi__icon ${iconClass || ''}`}><Icon name={icon} /></span>
        </div>
        <div className="kpi__value">{value}{unit && <span className="unit"> {unit}</span>}</div>
        <div className={`kpi__delta`}>
          <Icon name={arrow} />
          <span>{delta}</span>
          <span className="ctx">{deltaCtx}</span>
        </div>
        <Sparkline data={sparkData} color={sparkColor} />
      </div>
    </div>
  );
}

function KpiCards() {
  return (
    <section className="kpi-grid">
      <KpiCard
        label="Total Traces"
        icon="activity"
        value="128,547"
        delta="↑ 18.6%"
        deltaCtx="vs last 7 days"
        sparkData={[40,55,48,68,62,78,72,90,85,110,98,120]}
        sparkColor="#3b8df5"
      />
      <KpiCard
        label="Avg Eval Score"
        icon="star"
        iconClass="cyan"
        value="0.86"
        unit="/ 1.00"
        delta="↑ 6.3%"
        deltaCtx="vs last 7 days"
        sparkData={[60,62,58,64,66,70,72,68,74,76,78,82]}
        sparkColor="#22d3ee"
      />
      <KpiCard
        label="P95 Latency"
        icon="timer"
        iconClass="warn"
        value="2.48"
        unit="s"
        delta="↓ 9.7%"
        deltaCtx="vs last 7 days"
        sparkData={[80,76,82,70,74,68,72,64,68,60,62,58]}
        sparkColor="#f5b945"
      />
      <KpiCard
        label="Estimated Cost"
        icon="dollar-sign"
        iconClass="green"
        value="$1,842.63"
        delta="↓ 14.2%"
        deltaCtx="vs last 7 days"
        sparkData={[70,72,76,74,80,78,82,86,84,90,88,94]}
        sparkColor="#2ec27e"
      />
    </section>
  );
}

window.KpiCards = KpiCards;
window.Sparkline = Sparkline;
