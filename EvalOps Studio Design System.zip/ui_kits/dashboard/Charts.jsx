/* global React, Icon */
// Charts.jsx — Traces Over Time (line) and Evaluation Quality (stacked bars)

function TracesOverTime() {
  const days = ['May 13','May 14','May 15','May 16','May 17','May 18','May 19'];
  const data = [11200, 14800, 12200, 18400, 13600, 9400, 11800]; // peaked in middle
  const w = 560, h = 220, padL = 36, padR = 12, padT = 16, padB = 28;
  const maxY = 20000;
  const cw = w - padL - padR, ch = h - padT - padB;
  const xs = data.map((_, i) => padL + (i / (data.length - 1)) * cw);
  const ys = data.map(v => padT + ch - (v / maxY) * ch);
  const path = xs.map((x,i) => `${i===0?'M':'L'}${x},${ys[i]}`).join(' ');
  const area = `${path} L${xs[xs.length-1]},${padT+ch} L${xs[0]},${padT+ch} Z`;
  const yTicks = [0, 5000, 10000, 15000, 20000];
  return (
    <div className="card chart-card" style={{ minHeight: 280 }}>
      <div className="chart-head">
        <div className="title">Traces Over Time <Icon name="info" className="help" /></div>
        <button className="daily-toggle">Daily <Icon name="chevron-down" /></button>
      </div>
      <svg viewBox={`0 0 ${w} ${h}`} width="100%" height="220" preserveAspectRatio="none">
        <defs>
          <linearGradient id="trace-area" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.32" />
            <stop offset="100%" stopColor="#22d3ee" stopOpacity="0" />
          </linearGradient>
        </defs>
        {yTicks.map(t => {
          const y = padT + ch - (t / maxY) * ch;
          return (
            <g key={t}>
              <line x1={padL} y1={y} x2={w - padR} y2={y} stroke="#1c2748" strokeDasharray="2 4" />
              <text x={padL - 8} y={y + 3} fill="#5a6791" fontSize="10" textAnchor="end">
                {t === 0 ? '0' : `${t/1000}K`}
              </text>
            </g>
          );
        })}
        <path d={area} fill="url(#trace-area)" />
        <path d={path} fill="none" stroke="#22d3ee" strokeWidth="2" strokeLinejoin="round" />
        {xs.map((x, i) => (
          <g key={i}>
            <circle cx={x} cy={ys[i]} r="3" fill="#0a1024" stroke="#22d3ee" strokeWidth="2" />
            <text x={x} y={h - 8} fill="#5a6791" fontSize="10.5" textAnchor="middle">{days[i]}</text>
          </g>
        ))}
      </svg>
    </div>
  );
}

function EvalQuality() {
  const days = ['May 13','May 14','May 15','May 16','May 17','May 18','May 19'];
  // each: passed, review, failed (sums to 100)
  const data = [
    [62, 22, 16], [70, 18, 12], [64, 20, 16], [54, 26, 20],
    [60, 24, 16], [68, 20, 12], [72, 18, 10],
  ];
  const w = 560, h = 220, padL = 36, padR = 12, padT = 16, padB = 28;
  const cw = w - padL - padR, ch = h - padT - padB;
  const barW = cw / data.length * 0.55;
  const gap = cw / data.length;
  return (
    <div className="card chart-card" style={{ minHeight: 280 }}>
      <div className="chart-head">
        <div className="title">Evaluation Quality <Icon name="info" className="help" /></div>
        <div className="legend">
          <span className="legend-dot passed">Passed (≥ 0.7)</span>
          <span className="legend-dot review">Needs Review (0.4 – 0.7)</span>
          <span className="legend-dot failed">Failed (&lt; 0.4)</span>
        </div>
      </div>
      <div className="chart-head" style={{ marginBottom: 4 }}>
        <span /> <button className="daily-toggle">Daily <Icon name="chevron-down" /></button>
      </div>
      <svg viewBox={`0 0 ${w} ${h}`} width="100%" height="220" preserveAspectRatio="none">
        {[0, 50, 100].map(t => {
          const y = padT + ch - (t / 100) * ch;
          return (
            <g key={t}>
              <line x1={padL} y1={y} x2={w - padR} y2={y} stroke="#1c2748" strokeDasharray="2 4" />
              <text x={padL - 8} y={y + 3} fill="#5a6791" fontSize="10" textAnchor="end">{t}%</text>
            </g>
          );
        })}
        {data.map(([p, r, f], i) => {
          const cx = padL + gap * (i + 0.5);
          const x = cx - barW / 2;
          const fH = (f / 100) * ch;
          const rH = (r / 100) * ch;
          const pH = (p / 100) * ch;
          let y = padT + ch;
          return (
            <g key={i}>
              <rect x={x} y={y - fH} width={barW} height={fH} fill="#ef5d5d" rx="1" />
              <rect x={x} y={y - fH - rH} width={barW} height={rH} fill="#f5b945" />
              <rect x={x} y={y - fH - rH - pH} width={barW} height={pH} fill="#2ec27e" rx="1" />
              <text x={cx} y={h - 8} fill="#5a6791" fontSize="10.5" textAnchor="middle">{days[i]}</text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

function Charts() {
  return (
    <section className="chart-row">
      <TracesOverTime />
      <EvalQuality />
    </section>
  );
}

window.Charts = Charts;
